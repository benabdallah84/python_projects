## MORE CODE ABOVE

class FindMovieForm(FlaskForm):
    title = StringField("Movie Title", validators=[DataRequired()])
    submit = SubmitField("Add Movie")

@app.route("/add", methods=["GET", "POST"])
def add_movie():
    form = FindMovieForm()
    return render_template("add.html", form=form)
  
  ## MORE CODE BELOW