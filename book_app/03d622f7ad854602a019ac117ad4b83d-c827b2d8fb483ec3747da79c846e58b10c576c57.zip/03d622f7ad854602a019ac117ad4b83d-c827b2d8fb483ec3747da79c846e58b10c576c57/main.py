##MORE CODE ABOVE

@app.route('/')
def home():
    return render_template("index.html", books=all_books)
  
##MORE CODE BELOW