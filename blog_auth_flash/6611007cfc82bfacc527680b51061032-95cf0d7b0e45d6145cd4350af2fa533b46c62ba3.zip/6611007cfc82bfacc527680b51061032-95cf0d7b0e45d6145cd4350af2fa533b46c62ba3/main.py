## MORE CODE ABOVE

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('get_all_posts'))

## MORE CODE BELOW